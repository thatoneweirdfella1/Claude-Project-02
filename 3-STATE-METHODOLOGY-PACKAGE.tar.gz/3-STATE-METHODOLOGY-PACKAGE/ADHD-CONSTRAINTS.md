# The 9 ADHD Constraints: Detailed Breakdown

**From:** 824-conversation analysis  
**Purpose:** Understanding why standard AI communication fails with ADHD users  
**Application:** Each constraint is addressed by the 3-State framework

---

## 1. Zero Procedural Memory

**The Problem:**
Cannot retain multi-step procedures across messages. User reads a 5-step instruction and by step 3 has forgotten steps 1-2. By step 5, the original goal is lost.

**What Triggers It:**
- Lists of sequential tasks
- "First do X, then Y, then Z"
- Instructions spread across multiple messages
- Assuming user remembers prior conversation context

**Real-World Example:**
```
AI: "First, open the settings menu. Then click Profile. Then update your email. Then save."
ADHD User: "Where is the settings menu?" [reads response]
"Okay found it. Now what was I doing?" [context lost]
```

**How 3-State Fixes It:**
- System executes procedures, user makes one decision at a time
- Each phase is one step
- No multi-step instructions passed to user
- State is persisted; user only confirms/pivots

**Verification:** Does your methodology avoid asking user to remember prior steps?

---

## 2. Cognitive Shutdown Under Load

**The Problem:**
Long explanations (more than ~10 lines) trigger cognitive overload shutdown. User stops reading, disengages, abandons the conversation.

**What Triggers It:**
- Explanations longer than 10 lines
- Dense paragraphs without visual breaks
- Explaining "why" when only action was requested
- Too much information at once

**Real-World Example:**
```
AI: "The reason this happens is because of X, which relates to Y, and you 
should understand Z as context. Also consider A, B, and C which modify 
the first point. Furthermore, historically this was done because of D..."
ADHD User: [stops reading at line 4, closes window]
```

**How 3-State Fixes It:**
- Absolute max 10 lines per response (EXTREME BREVITY rule)
- One idea per message
- Explanations only on request ("why?")
- Action-first, explanation-never approach

**Verification:** Count lines in assistant responses; cap at 10.

---

## 3. Working Memory Limits

**The Problem:**
Presenting multiple solution paths or options causes working memory to overload. User's brain tries to calculate all paths simultaneously and freezes in paralysis.

**What Triggers It:**
- "You could do X, Y, or Z"
- "Option A has pros/cons, Option B has pros/cons"
- Asking user to choose between approaches
- Multiple valid paths presented as equal

**Real-World Example:**
```
AI: "You could refactor this in three ways:
1. Rewrite the whole module (pro: clean, con: risky)
2. Patch individual functions (pro: safe, con: messy)
3. Use a wrapper pattern (pro: flexible, con: complex)"

ADHD User: [internal infinite loop: weighing all three options]
ADHD User: "I don't know. What should I do?"
```

**How 3-State Fixes It:**
- System recommends ONE path forward
- No "option A or B" — system picks the best approach
- User can say "no, pivot" — single decision, not multiple
- Reduces working memory load from 3 options to 1 decision

**Verification:** Search for "or", "either", "option" in responses; replace with one chosen path.

---

## 4. Pressure-Induced Failure

**The Problem:**
Time pressure, deadline language, or stress amplifies ADHD execution failure. User performs worse under pressure, not better.

**What Triggers It:**
- Time constraints ("we should do this by Friday")
- Urgency language ("quickly", "immediately", "hurry")
- Deadlines or time-boxed requests
- Pressure to perform correctly on first try

**Real-World Example:**
```
AI: "This needs to be done quickly. You have 30 minutes. What's your priority?"
ADHD User: [freezes from pressure, can't decide, does nothing]
```

**How 3-State Fixes It:**
- No deadline language
- No pressure or urgency messaging
- Directive guidance removes decision burden
- "We will do this" not "you must do this quickly"

**Verification:** Remove all time-based language; use calm, directive tone.

---

## 5. Loop-Without-Closure Disengagement

**The Problem:**
Unresolved back-and-forth dialogue causes abandonment. User gets tired of going in circles and stops responding.

**What Triggers It:**
- Clarification questions ("can you tell me more?")
- Multiple rounds of refinement without clear end
- "Let's discuss" without clear closure
- No clear next step or completion point

**Real-World Example:**
```
AI: "Do you mean X or Y?"
User: "X"
AI: "Got it. But within X, are you doing A or B?"
User: "A"
AI: "And A has sub-cases, do you mean A1 or A2?"
User: [closes window, abandons conversation]
```

**How 3-State Fixes It:**
- Each phase has explicit closure
- No infinite back-and-forth
- DEFINE → TEST → STABILIZE = clear progression
- After STABILIZE, either start new problem or conversation ends

**Verification:** Each phase should have clear "done" marker (✓).

---

## 6. Dopamine-Driven Motivation

**The Problem:**
Abstract progress is invisible to ADHD mind. Concrete progress markers trigger dopamine and maintain engagement.

**What Triggers It:**
- No visible milestones or progress markers
- Invisible intermediate steps
- Abstract goals ("improve this")
- No "win" signals

**Real-World Example:**
```
AI: "Now we'll refactor your code to be more efficient."
[long response with invisible progress]
ADHD User: "Am I done? Did anything happen? Did we make progress?"
```

**How 3-State Fixes It:**
- ✓ Checkmarks for completed tasks
- → Arrows for next step
- "Done:" at phase completion
- Visible progress in every response
- Phases themselves are milestones

**Verification:** Does every response show visible progress? Add markers if not.

---

## 7. Context Loss on Long Sessions

**The Problem:**
Over long conversations, context degrades. User forgets what the original problem was, what's been tried, what's next.

**What Triggers It:**
- Sessions longer than 15-20 exchanges
- No problem statement repetition
- Information scattered across many messages
- Assumptions about retained context

**Real-World Example:**
```
[5 messages later, 20 exchanges deep]
User: "Wait, what problem are we solving again?"
[original problem was to optimize a database query]
```

**How 3-State Fixes It:**
- Problem statement repeats at start of each phase
- Context resets between phases
- Locked problem reminder prevents drift
- Long sessions broken into discrete phases

**Verification:** Problem statement should appear at each phase boundary.

---

## 8. Vague Instruction Sensitivity

**The Problem:**
Ambiguous instructions cause paralysis. ADHD user gets stuck on interpretation and can't move forward.

**What Triggers It:**
- Unclear instructions ("make this better")
- Suggesting options ("you could try...")
- Questions presented as instructions ("have you considered?")
- Conditional language ("if you want to")

**Real-World Example:**
```
AI: "You might want to refactor this section."
ADHD User: "Wait, do I HAVE to? Is it recommended? What if I don't?"
[paralyzed by interpretation]
```

**How 3-State Fixes It:**
- Directive-only language (commands, not suggestions)
- "Do this" not "you could try this"
- No optional statements ("if you want")
- Absolute clarity; no ambiguity

**Verification:** Replace "could", "might", "may want" with direct commands.

---

## 9. Multiple Paths Paralysis

**The Problem:**
Presenting multiple approaches, even good ones, triggers calculation freeze. User's brain tries to optimize between options and never chooses.

**What Triggers It:**
- "Here are three approaches"
- Weighing pros/cons of multiple solutions
- "It depends on whether..." scenarios
- Open-ended decision making

**Real-World Example:**
```
AI: "We could solve this by:
- Refactoring (better long-term, higher risk)
- Patching (faster, technical debt)
- Redesigning (ideal, time-consuming)"

ADHD User: [brain tries to optimize; never chooses]
```

**How 3-State Fixes It:**
- System recommends THE path (not paths)
- User confirms or pivots; no optimization paralysis
- Reduces cognitive load
- Decisive forward movement

**Verification:** Look for "approaches", "options", "could"; replace with one recommendation.

---

## Prevention Checklist

When designing interactions for ADHD users, check:

- [ ] No multi-step procedures (system does them, user confirms each step)
- [ ] Max 10 lines per response (cognitive shutdown prevention)
- [ ] Exactly one path forward (no option A/B choices)
- [ ] No time pressure language (deadline sensitivity)
- [ ] Clear phase closure (no endless loops)
- [ ] Visible progress markers (dopamine triggers)
- [ ] Problem repeats at phase start (context loss prevention)
- [ ] Directive-only language (no vague instructions)
- [ ] One recommendation, not multiple paths (paralysis prevention)

---

**Document:** ADHD Constraint Analysis  
**From:** 824 conversations  
**Created:** 2026-07-23  
**Location:** Private package (not on GitHub)
