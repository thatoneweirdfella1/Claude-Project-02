# Next Steps: Activating 3-State Methodology

**Status:** Core feature complete and tested (598 tests passing). Ready for 6 integration tasks.

**How to Use This Document:**
1. Pick one task below
2. Implement it in the app
3. Run `npm test` to verify nothing broke
4. Mark task as ✅ DONE
5. Move to next task

---

## Task 1: Wire Locked Problem Input in Composer UI

**What:** Add input field to Composer for user to lock problem during DEFINE phase  
**When Active:** Only visible when methodology = "3-state" AND phase = "define"

**Files to Modify:**
- `src/components/composer/ControlRow.tsx` (or equivalent Composer component)

**Implementation:**
```typescript
// Add conditional rendering:
{session.methodology === "3-state" && session.methodologyPhase === "define" && (
  <input
    type="text"
    placeholder="Lock problem statement..."
    value={session.lockedProblemStatement}
    onChange={(e) => session.setLockedProblemStatement(e.target.value)}
  />
)}
```

**How to Verify:**
- Methodology selector shows "3-State"
- Phase is "define"
- Input field appears
- Typing in it updates `session.lockedProblemStatement`

**Status:** ❌ NOT YET DONE

---

## Task 2: Enable 3-State in System Prompts

**What:** Use methodology-aware prompts based on current phase  
**Impact:** AI responses adapt to DEFINE/TEST/STABILIZE phase

**Files to Modify:**
- System prompt generation (likely `src/services/prompts.ts` or API handler)

**Implementation:**
```typescript
// When generating system prompt:
import { getPhasePromptTemplate } from "../services/methodologyEngine";

const systemPrompt = isThreeState
  ? getPhasePromptTemplate(session.methodologyPhase)
  : standardPrompt;
```

**How to Verify:**
- When phase = "define", system prompt contains "Lock and define the problem"
- When phase = "test", system prompt contains "Validate your approach. Fact-check claims"
- When phase = "stabilize", system prompt contains "Deliver the final, audited result"

**Status:** ❌ NOT YET DONE

---

## Task 3: Wire Phase Transitions

**What:** Automatically advance phases based on message count  
**Impact:** Phases progress DEFINE → TEST → STABILIZE automatically

**Files to Modify:**
- Message sending handler (where messages are sent to API)
- Message receiving handler (after assistant responds)

**Implementation:**
```typescript
// After assistant responds:
import { checkPhaseAutoAdvance } from "../services/methodologyEngine";

if (session.methodology === "3-state") {
  const { shouldAdvance, nextPhase } = checkPhaseAutoAdvance(
    session.methodologyPhase,
    session.conversation,
    session.methodology
  );
  
  if (shouldAdvance && nextPhase) {
    session.setMethodologyPhase(nextPhase);
  }
}
```

**How to Verify:**
- Start with phase = "define"
- Send 1-3 messages
- Phase auto-advances to "test"
- Continue; phase auto-advances to "stabilize"

**Status:** ❌ NOT YET DONE

---

## Task 4: Connect Self-Critique to Responses

**What:** Generate critique on assistant messages during TEST phase  
**Impact:** TEST phase shows compliance checking and confidence scoring

**Files to Modify:**
- Message streaming handler (where assistant response is received)
- Message display component

**Implementation:**
```typescript
// When displaying assistant message in TEST phase:
import { generateSelfCritique } from "../services/methodologyEngine";

if (session.methodology === "3-state" && session.methodologyPhase === "test") {
  const { critique, confidence } = generateSelfCritique(
    message.content,
    session.lockedProblemStatement
  );
  
  // Pass to TransparencyCard:
  <TransparencyCard 
    answer={message.content} 
    showSelfCritique={true}
  />
}
```

**How to Verify:**
- Methodology is "3-State", phase is "test"
- Assistant sends a response
- TransparencyCard appears below message
- Shows compliance analysis and confidence %

**Status:** ❌ NOT YET DONE

---

## Task 5: Extract and Display Hallucination Audits

**What:** Show factual claims with confidence scores  
**Impact:** TEST phase shows which claims are verified vs. uncertain

**Files to Modify:**
- Message display component
- Possibly create new component for audit display

**Implementation:**
```typescript
// When displaying TEST phase responses:
import { extractClaimsForAudit } from "../services/methodologyEngine";

const audits = extractClaimsForAudit(message.content);

// Display audits:
{audits.map(audit => (
  <div key={audit.claimId}>
    <span>{audit.text}</span>
    <span>Confidence: {audit.confidence * 100}%</span>
  </div>
))}
```

**How to Verify:**
- Methodology "3-State", phase "test"
- Assistant message contains factual claims
- Claims displayed with confidence scores
- User can see which claims are high vs. low confidence

**Status:** ❌ NOT YET DONE

---

## Task 6: Apply ADHD Rules to Generated Output

**What:** Enforce 7 communication rules on all 3-state responses  
**Impact:** All 3-state responses automatically follow ADHD rules

**Files to Modify:**
- Response generation / post-processing (before sending to user)

**Implementation:**
```typescript
// After generating response:
import { applyADHDRules, analyzeADHDCompliance } from "../services/methodologyEngine";

if (session.methodology === "3-state") {
  // Enforce rules:
  let output = applyADHDRules(generatedResponse);
  
  // Analyze compliance:
  const analysis = analyzeADHDCompliance(output);
  if (!analysis.complies) {
    console.warn("ADHD compliance breaches:", analysis.breaches);
    // Could auto-fix or alert
  }
}
```

**How to Verify:**
- Methodology "3-State"
- Generated responses:
  - Max 10 lines
  - Have ✓, →, "Done:", "Next:" markers
  - Use directive language only
  - No "could", "might", "if you want"

**Status:** ❌ NOT YET DONE

---

## Task 7 (Optional): Record Methodology Sessions for Learning

**What:** Log every 3-state session to track usage and patterns  
**Impact:** Build learning dataset on what works for ADHD user

**Files to Modify:**
- Session close / save handler

**Implementation:**
```typescript
// When closing session:
import { buildSessionRecord } from "../services/sessionLifecycle";

if (session.methodology === "3-state") {
  account.recordMethodology({
    // MethodologyEntry structure from types.ts
    id: generateId(),
    sessionId: session.id,
    methodology: "3-state",
    phase: session.methodologyPhase,
    lockedProblemStatement: session.lockedProblemStatement,
    hallucinations: [], // collected during session
    timestamp: Date.now(),
  });
}
```

**How to Verify:**
- Create 3-state session, complete it
- Check `account.methodologyLog` has entry for this session
- Log is capped at 200 entries (oldest first)

**Status:** ❌ NOT YET DONE

---

## Implementation Sequence (Recommended)

### Phase 1: Basic Structure (Tasks 1-2)
1. Add locked problem input (Task 1)
2. Wire methodology-aware prompts (Task 2)
→ **Result:** UI works, prompts adapt by phase

### Phase 2: Flow Control (Task 3)
3. Wire phase transitions (Task 3)
→ **Result:** App flows through DEFINE → TEST → STABILIZE automatically

### Phase 3: Feedback (Tasks 4-5)
4. Connect self-critique (Task 4)
5. Extract claims for audit (Task 5)
→ **Result:** User sees compliance checking during TEST phase

### Phase 4: Enforcement (Task 6)
6. Apply ADHD rules (Task 6)
→ **Result:** All responses follow 7 communication rules

### Phase 5: Learning (Task 7 - Optional)
7. Record sessions (Task 7)
→ **Result:** Usage patterns captured for future learning

---

## Verification Checklist

After Each Task:
```bash
# Run tests
npm test

# Should see: 598 tests passing
# No new failures

# Manual check
npm run dev
# Try the feature in the app
```

After All Tasks:
```bash
# Full test suite
npm test

# TypeScript check
npx tsc --noEmit

# Lint check (if applicable)
npm run lint
```

---

## Quick Reference Commands

```bash
# Find where system prompts are generated
grep -r "system.*prompt" src/ --include="*.ts" --include="*.tsx"

# Find message sending handler
grep -r "sendMessage\|submitMessage" src/ --include="*.ts" --include="*.tsx"

# Find where responses are displayed
grep -r "ConversationMessage\|assistant.*role" src/ --include="*.tsx"

# Find session save/close handler
grep -r "closeSession\|saveSession\|archiveSession" src/ --include="*.ts"

# View all 3-state related code
grep -r "methodology\|3-state\|3State" src/ --include="*.ts" --include="*.tsx" | head -20
```

---

**Document:** Integration Task Sequence  
**Created:** 2026-07-23  
**Status:** Ready for implementation  
**Location:** Private package (not on GitHub)
