# Integration Plan: Activating 3-State Methodology

**Status:** Core feature implemented and tested. Ready for 6 integration tasks.

---

## What's Already Done ✅

- Type definitions (types.ts)
- Store management (accountStore, sessionStore)
- Core engine (methodologyEngine.ts with all ADHD rules)
- UI components (MethodologyDropdown, TransparencyCard)
- All tests passing (598/598)

**Location:** GitHub `build` branch  
**Verification:** `npm test` shows 598 passing

---

## What Needs to Happen ⏳

### Task 1: Enable 3-State in System Prompts
**What:** Modify system prompt generation to use methodology-aware templates  
**Files to find:** System prompt templates (likely `src/services/prompts.ts` or similar)  
**What to add:** Call `getPhasePromptTemplate(phase)` when generating prompts  
**How to verify:** Search code for "getPhasePromptTemplate"  
**Status:** ❌ NOT YET DONE

### Task 2: Wire Phase Transitions
**What:** Automatically advance phases based on message count  
**Files to find:** Chat message sending logic (likely in composer or API handler)  
**What to add:** Call `checkPhaseAutoAdvance()` after each message  
**How to verify:** Look for "checkPhaseAutoAdvance" in code  
**Status:** ❌ NOT YET DONE

### Task 3: Display Hallucination Audits
**What:** Show confidence scores and fact-check results in chat  
**Files to find:** Message display components  
**What to add:** Render HallucinationAudit data from methodologyLog  
**How to verify:** Messages should show confidence % when 3-state + TEST phase  
**Status:** ❌ NOT YET DONE

### Task 4: Add Locked Problem Input
**What:** UI field for user to lock problem statement in DEFINE phase  
**Files to find:** Composer component  
**What to add:** Input field that's only visible when phase = "define"  
**How to verify:** Check ControlRow component has locked-problem input  
**Status:** ❌ NOT YET DONE

### Task 5: Connect Self-Critique to Responses
**What:** Generate critique automatically on assistant responses  
**Files to find:** Message streaming/response handler  
**What to add:** Call `generateSelfCritique()` and pass result to TransparencyCard  
**How to verify:** Self-critique should appear below assistant messages in TEST phase  
**Status:** ❌ NOT YET DONE

### Task 6: Record Methodology Usage
**What:** Log every 3-state session for learning/auditing  
**Files to find:** Session close/save handler  
**What to add:** Call `recordMethodology()` when session ends  
**How to verify:** Check accountStore.methodologyLog after session closes  
**Status:** ❌ NOT YET DONE

---

## Quick Verification Commands

```bash
# Are all core files present?
ls -la src/services/methodologyEngine.ts
ls -la src/components/methodology/MethodologyDropdown.tsx
ls -la src/components/streaming/TransparencyCard.tsx

# Do tests pass?
npm test

# What needs integration?
grep "❌ NOT YET DONE" INTEGRATION-PLAN.md | wc -l
```

---

## Next Immediate Steps

1. Read **NEXT-STEPS.md** for step-by-step activation guide
2. Pick one task above, complete it
3. Run `npm test` to verify no breaks
4. Move marker from ❌ to ✅
5. Repeat for next task

---

**Document:** Integration Checklist  
**Created:** 2026-07-23  
**Location:** Private package (not on GitHub)
