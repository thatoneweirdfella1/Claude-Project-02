# Complete File Inventory: 3-State Methodology

**Location:** All files are on GitHub `build` branch  
**Status:** All implemented, tested, 598 tests passing

---

## Type Definitions

### `src/stores/types.ts`
**What:** TypeScript definitions for all methodology types  
**New Types Added:**
- `MethodologyEntry` — Record of one methodology session (id, sessionId, methodology, phase, lockedProblemStatement, hallucinations[], timestamp)
- `MethodologyType` — "standard" | "3-state"
- `MethodologyPhase` — "define" | "test" | "stabilize"
- `HallucinationAudit` — Claim auditing (claimId, text, confidence, verified, notes)

**Modified Interfaces:**
- `SessionState` — Added: methodology, methodologyPhase, lockedProblemStatement
- `AccountState` — Added: methodologyLog (bounded to 200 entries)

**Verify Command:** `grep -n "MethodologyEntry\|MethodologyType\|MethodologyPhase\|HallucinationAudit" src/stores/types.ts`

---

## Store Management

### `src/stores/accountStore.ts`
**What:** Account-level state management for methodology logging  
**Changes:**
- Added constant: `MAX_METHODOLOGY_ENTRIES = 200`
- Added initial state: `methodologyLog: []`
- Added to persisted keys: "methodologyLog"
- Added action: `recordMethodology(entry)` — logs methodology usage, caps at 200 entries (oldest first)

**Verify Command:** `grep -n "MAX_METHODOLOGY\|recordMethodology\|methodologyLog" src/stores/accountStore.ts`

### `src/stores/sessionStore.ts`
**What:** Session-level state management for methodology control  
**Changes:**
- Added to `createInitialSessionState()`:
  - `methodology: "standard"`
  - `methodologyPhase: "define"`
  - `lockedProblemStatement: ""`
- Added to `SESSION_PERSISTED_KEYS`: "methodology", "methodologyPhase", "lockedProblemStatement"
- Added actions:
  - `setMethodology(methodology)` — Select methodology type
  - `setMethodologyPhase(phase)` — Update current phase
  - `setLockedProblemStatement(statement)` — Lock problem for DEFINE phase

**Verify Command:** `grep -n "methodology\|lockedProblem\|setMethodologyPhase\|setMethodology" src/stores/sessionStore.ts | head -20`

---

## Core Engine

### `src/services/methodologyEngine.ts` (300+ lines)
**What:** All ADHD rules, compliance scoring, phase detection, critique generation  
**Exports:**
- Constants: `ADHD_CONSTRAINTS`, `ADHD_COMMUNICATION_RULES`
- Interfaces: `PhaseDetectionResult`, `HallucinationCheckResult`, `ADHDCommunicationAnalysis`
- Functions:
  - `detectPhaseTransition(phase, messageCount)` — Determine when to advance phases
  - `analyzeADHDCompliance(message)` — Score message against 7 communication rules
  - `generateSelfCritique(answer, lockedProblem)` — Create TEST phase self-assessment
  - `extractClaimsForAudit(message)` — Extract factual claims for hallucination audit
  - `getPhasePromptTemplate(phase)` — Get phase-specific system prompt
  - `checkPhaseAutoAdvance(phase, messages, methodology)` — Auto-advance phases
  - `applyADHDRules(output)` — Enforce ADHD rules on generated output

**Verify Command:** `grep -n "export function\|export const" src/services/methodologyEngine.ts`

---

## UI Components

### `src/components/methodology/MethodologyDropdown.tsx` (NEW)
**What:** Selector component for choosing Standard vs. 3-State methodology  
**Props:**
- Reads current `methodology` from `useSessionStore`
- Writes to `setMethodology` action
- Options: Standard, 3-State

**Verify Command:** `ls -la src/components/methodology/MethodologyDropdown.tsx`

### `src/components/methodology/index.ts` (NEW)
**What:** Export file for methodology components  
**Exports:** `MethodologyDropdown`

**Verify Command:** `cat src/components/methodology/index.ts`

### `src/components/composer/ControlRow.tsx` (MODIFIED)
**What:** Added MethodologyDropdown to the Composer control row  
**Change:** Added `<MethodologyDropdown />` in the control-row__dropdowns div

**Verify Command:** `grep -n "MethodologyDropdown" src/components/composer/ControlRow.tsx`

### `src/components/streaming/TransparencyCard.tsx` (NEW)
**What:** Component to display self-critique and confidence scoring during TEST phase  
**Props:**
- `answer: string` — The assistant response to critique
- `showSelfCritique?: boolean` — Whether to show the card

**Behavior:**
- Renders only when methodology is "3-state" AND phase is "test"
- Shows compliance analysis and confidence score
- Displays issues if any breaches detected

**Verify Command:** `ls -la src/components/streaming/TransparencyCard.tsx`

### `src/components/streaming/index.ts` (MODIFIED)
**What:** Export file for streaming components  
**Change:** Added export for `TransparencyCard`

**Verify Command:** `grep -n "TransparencyCard" src/components/streaming/index.ts`

---

## Tests & Contracts

### `src/services/sessionLifecycle.test.ts` (MODIFIED)
**Change:** Updated `session()` helper function to include three methodology fields  
```typescript
methodology: "standard",
methodologyPhase: "define",
lockedProblemStatement: "",
```

**Verify Command:** `grep -n "methodology\|lockedProblem" src/services/sessionLifecycle.test.ts`

### `src/stores/sessionStore.test.ts` (MODIFIED)
**Change:** Updated SESSION_PERSISTED_KEYS contract test  
- Old: Expected 9 fields
- New: Expects 12 fields (added 3 methodology fields)

**Verify Command:** `grep -n "SESSION_PERSISTED_KEYS" src/stores/sessionStore.test.ts -A 15`

### `src/stores/accountStore.test.ts` (MODIFIED)
**Change:** Updated ACCOUNT_PERSISTED_KEYS contract test  
- Old: Expected 13 fields
- New: Expects 15 fields (added methodologyLog and trashed)

**Verify Command:** `grep -n "ACCOUNT_PERSISTED_KEYS" src/stores/accountStore.test.ts -A 20`

### `src/services/persistence.test.ts` (MODIFIED)
**Change:** Updated persistence contract test to include all 12 session fields  
- Verified that persisted session state includes: draftInput, model, directness, techniques, context, conversation, statePills, variables, currentScreen, methodology, methodologyPhase, lockedProblemStatement

**Verify Command:** `grep -n "Object.keys(raw).sort()" src/services/persistence.test.ts -A 2`

---

## Documentation

### `CLAUDE.md` (MODIFIED)
**What:** Added "3-State Methodology" section to main project documentation  
**Location:** After "Design layouts" section  
**Content:** Full architecture, constraints, communication rules, failure modes, storage approach, reference to methodologyEngine.ts

**Verify Command:** `grep -n "## 3-State Methodology" CLAUDE.md -A 50`

### `BACKUP-CHANGES.md` (MODIFIED)
**What:** Transfer log documenting what was moved from feature branch to build  
**Content:** Dates, files, authorization, status, commits transferred, methodology details

**Verify Command:** `grep -n "3-State Methodology" BACKUP-CHANGES.md | head -5`

---

## Summary

**Total Files Modified:** 10  
**Total Files Created:** 3  
**Total Test Files Updated:** 4  

**Categories:**
- Type Definitions: 1 file
- Store Management: 2 files
- Core Engine: 1 file
- UI Components: 4 files
- Tests: 4 files
- Documentation: 2 files

**Test Status:** ✅ 598/598 tests passing  
**Compilation:** ✅ TypeScript clean  
**Persistence:** ✅ All contracts updated and verified

---

**Document:** File Inventory  
**Created:** 2026-07-23  
**Location:** Private package (not on GitHub)
